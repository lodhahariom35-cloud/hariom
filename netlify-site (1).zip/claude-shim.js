/* Netlify पर चलाने के लिए: ऐप के claude.use(...) कॉल्स को आम ब्राउज़र/Netlify सुविधाओं से जोड़ता है */
(function(){
  const PASS_KEY='notesApp.passcode';
  const b64=b=>new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(String(r.result).split(',')[1]);r.onerror=rej;r.readAsDataURL(b)});

  async function sample(prompt,opts){
    opts=opts||{};
    const images=[];
    for(const b of (opts.images||[])) images.push({media_type:b.type||'image/jpeg',data:await b64(b)});
    const send=()=>{
      const headers={'content-type':'application/json'};
      const pc=localStorage.getItem(PASS_KEY);if(pc)headers['x-passcode']=pc;
      return fetch('/api/ai',{method:'POST',headers,body:JSON.stringify({prompt,images})});
    };
    let res=await send();
    if(res.status===401){
      const p=window.prompt('इस ऐप का पासकोड डालिए:');
      if(!p)throw new Error('passcode');
      localStorage.setItem(PASS_KEY,p);res=await send();
    }
    if(!res.ok)throw new Error('AI error '+res.status);
    const reader=res.body.getReader(),dec=new TextDecoder();let buf='',text='';
    for(;;){
      const {done,value}=await reader.read();if(done)break;
      buf+=dec.decode(value,{stream:true});
      let i;
      while((i=buf.indexOf('\n'))>=0){
        const line=buf.slice(0,i).trim();buf=buf.slice(i+1);
        if(line.startsWith('data:')){
          try{const j=JSON.parse(line.slice(5));if(j.type==='content_block_delta'&&j.delta&&j.delta.text)text+=j.delta.text}catch(e){}
        }
      }
    }
    if(!text)throw new Error('empty');
    return {text};
  }

  const downloads={save:async({filename,data})=>{
    const a=document.createElement('a');a.href=URL.createObjectURL(data);a.download=filename;
    document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),5000);
  }};

  /* dictation/user/db = null  →  ऐप अपने आप ब्राउज़र का माइक (Web Speech API) और localStorage इस्तेमाल करता है */
  window.claude={use:async name=>name==='sample'?sample:name==='downloads'?downloads:null};
})();
