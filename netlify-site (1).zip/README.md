# स्टडी नोट्स मेकर – Netlify Deployment

## फ़ाइलें
- index.html – पूरा ऐप
- claude-shim.js – ऐप को Netlify पर चलाने वाला छोटा जोड़
- netlify/functions/ai.mjs – Anthropic API का proxy
- netlify.toml – Netlify settings

## Deploy (सबसे भरोसेमंद तरीका: GitHub)
1. इस फ़ोल्डर को एक GitHub repo में डालिए।
2. Netlify → Add new site → Import from Git → वह repo चुनिए (Build command खाली, Publish directory ".").
3. Site configuration → Environment variables में जोड़िए:
   - ANTHROPIC_API_KEY = आपकी Anthropic API key (ज़रूरी)
   - APP_PASSCODE = कोई पासकोड (वैकल्पिक, पर सलाह है; वरना कोई भी आपकी key का खर्च कर सकता है)
   - ANTHROPIC_MODEL = मॉडल का नाम (वैकल्पिक, default: claude-sonnet-5-5)
4. Deploy दोबारा चलाइए (env variables जोड़ने के बाद)।

## CLI से deploy
npm i -g netlify-cli
netlify login
netlify deploy --prod --dir=.
(पहले netlify.toml वाले फ़ोल्डर में रहिए; env variables Netlify dashboard में डालिए।)

## ध्यान दें
- API key इस्तेमाल होने पर आपके Anthropic खाते से पैसे कटते हैं।
- माइक के लिए Chrome (HTTPS) चाहिए; Netlify HTTPS देता है।
- नोट्स ब्राउज़र के localStorage में सेव होते हैं (एक डिवाइस तक सीमित)।
- Netlify की free/default सीमा में function का समय कम हो सकता है; इसीलिए streaming इस्तेमाल की गई है।
