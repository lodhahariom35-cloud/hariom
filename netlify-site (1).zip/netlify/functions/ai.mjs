// Anthropic API का सुरक्षित proxy (API key सिर्फ़ Netlify के environment variables में रहती है)
export default async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });

  const key = Netlify.env.get('ANTHROPIC_API_KEY');
  if (!key) return new Response('ANTHROPIC_API_KEY set nahi hai', { status: 500 });

  const pass = Netlify.env.get('APP_PASSCODE');            // optional
  if (pass && req.headers.get('x-passcode') !== pass) return new Response('Unauthorized', { status: 401 });

  let body;
  try { body = await req.json(); } catch { return new Response('Bad request', { status: 400 }); }
  const prompt = String(body.prompt || '').slice(0, 120000);
  const images = Array.isArray(body.images) ? body.images.slice(0, 8) : [];

  const content = [
    ...images.map(i => ({ type: 'image', source: { type: 'base64', media_type: i.media_type || 'image/jpeg', data: i.data } })),
    { type: 'text', text: prompt }
  ];

  const up = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({
      model: Netlify.env.get('ANTHROPIC_MODEL') || 'claude-sonnet-5-5',
      max_tokens: 8000,
      stream: true,
      messages: [{ role: 'user', content }]
    })
  });

  if (!up.ok) return new Response(await up.text(), { status: up.status });
  return new Response(up.body, { headers: { 'content-type': 'text/event-stream', 'cache-control': 'no-store' } });
};

export const config = { path: '/api/ai' };
